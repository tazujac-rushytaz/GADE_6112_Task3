﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Assignment1_16093549
{
    class Map
    {
        private const int MAX_RANDOM_UNITS = 50;
        public const string FIELD_SYMBOL = ".";
        public string[,] grid = new string[20, 20];
        private List<Unit> unitsOnMap = new List<Unit>();
        private List<Building> buildingsOnMap = new List<Building>();
        private int numberOfUnitsOnMap = 0;
        private int numberOfBuildingsOnMap = 0;

        public string[,] Grid
        {
            get
            {
                return grid;
            }
        }
        public List<Unit> UnitsOnMap
        {
            get
            {
                return unitsOnMap;
            }
        }

        public void clearField()
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    grid[i, j] = FIELD_SYMBOL;

                }
            }
        }

        public void populate()
        {
            Random rnd = new Random();
            int numberRandomUnits = rnd.Next(0, MAX_RANDOM_UNITS) + 1;
            int x, y, randomAttackRange;
            bool attackOption;
            string team;

            // clear Field
            clearField();
            
            for (int k = 1; k <= numberRandomUnits; k++)
            {

                // Ensure x, y is not occupied by another unit
                do
                {
                    x = rnd.Next(0, 20);
                    y = rnd.Next(0, 20);
                } while (grid[x, y] != FIELD_SYMBOL);

                // generate randomly either a meleeunit or rangedunit and place on map
                if (rnd.Next(1, 3) == 1)
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;   // Randomize attack option 
                    team = rnd.Next(0, 2) == 1 ? "RED" : "GREEN";
                    Unit tmp = new MeleeUnit(x, y, 100, -1, attackOption, 1, team, "M", "Club");
                    unitsOnMap.Add(tmp);

                    grid[x, y] = tmp.Symbol;

                    //update arraySize
                    numberOfUnitsOnMap++;
                }
                else
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;
                    randomAttackRange = rnd.Next(1, 20);
                    team = rnd.Next(0, 2) == 1 ? "RED" : "GREEN";
                    Unit tmp = new RangedUnit(x, y, 100, -1, attackOption, randomAttackRange, team, "R", "Gun");
                    unitsOnMap.Add(tmp);

                    grid[x, y] = tmp.Symbol;

                    //update arraySize
                    numberOfUnitsOnMap++;
                }
            }
        }


        private void moveOnMap(Unit u, int newX, int newY)
        {
            grid[u.X, u.Y] = FIELD_SYMBOL;
            grid[newX, newY] = u.Symbol;
        }

        public void update(Unit u, int newX, int newY)
        {
            if ((newX >= 0 && newX < 20) && (newY >= 0 && newY < 20))
            {
                moveOnMap(u, newX, newY);
                u.move(newX, newY);
            }
        }

        public void checkHealth()
        {
            for (int i = 0; i < numberOfUnitsOnMap; i++)
            {
                if (!unitsOnMap[i].isAlive())
                {
                    grid[unitsOnMap[i].X, unitsOnMap[i].Y] = FIELD_SYMBOL; // remove units from grid //
                    numberOfUnitsOnMap--;                        // remove unit from list
                }
            }
        }

        public void saveMap()
        {

            try
            {
                File.Delete(@"C:\GADE\Assignment1_16093549\Assignment1_16093549\bin\Debug\Files\MeleeUnit.txt");
                File.Delete(@"C:\GADE\Assignment1_16093549\Assignment1_16093549\bin\Debug\Files\RangedUnit.txt");
                foreach (Unit u in unitsOnMap)
                {
                    u.save();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            try
            {

                File.Delete(@"C:\GADE\Assignment1_16093549\Assignment1_16093549\bin\Debug\Files\ResourceBuilding.txt");
                File.Delete(@"C:\GADE\Assignment1_16093549\Assignment1_16093549\bin\Debug\Files\FactoryBuilding.txt");
                foreach (Building b in buildingsOnMap)
                {
                    b.save();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public bool loadMap()
        {
            bool success = true;
            string input;
            int x;
            int y;
            int health;
            int speed;
            bool attack;
            int attackRange;
            string faction;
            string symbol;
            string name;
            string resourceType;
            int resourcesPerGameTick;
            int resourcesRemaining;
            int unitsToProduce;
            int gameTicksPerProduction;
            int spawnPointX;
            int spawnPointY;

            clearField();

            // load MeleeUnit objects from the file
            try
            {
                FileStream inFile = new FileStream(@"Files\MeleeUnit.txt", FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                input = reader.ReadLine();
                while (input != null)
                {
                    x = int.Parse(input);
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    speed = int.Parse(reader.ReadLine());
                    attack = bool.Parse(reader.ReadLine());
                    attackRange = int.Parse(reader.ReadLine());
                    faction = (reader.ReadLine());
                    symbol = (reader.ReadLine());
                    name = (reader.ReadLine());
                    MeleeUnit mU = new MeleeUnit(x, y, health, speed, attack, attackRange, faction, symbol, name);
                    unitsOnMap.Add(mU);
                    grid[x, y] = mU.Symbol;

                    //update arraySize
                    numberOfUnitsOnMap++;
                    input = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }
            catch (IOException fe)
            {
                success = false;
                Console.WriteLine(fe.Message);
            }

            // load RangedUnit objects from the file
            try
            {
                FileStream inFile = new FileStream(@"Files\RangedUnit.txt", FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                input = reader.ReadLine();
                while (input != null)
                {
                    x = int.Parse(input);
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    speed = int.Parse(reader.ReadLine());
                    attack = bool.Parse(reader.ReadLine());
                    attackRange = int.Parse(reader.ReadLine());
                    faction = (reader.ReadLine());
                    symbol = (reader.ReadLine());
                    name = (reader.ReadLine());
                    RangedUnit rU = new RangedUnit(x, y, health, speed, attack, attackRange, faction, symbol, name);
                    unitsOnMap.Add(rU);
                    grid[x, y] = rU.Symbol;

                    //update arraySize
                    numberOfUnitsOnMap++;
                    input = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }
            catch (IOException fe)
            {
                success = false;
                Console.WriteLine(fe.Message);
            }

            // load ResourceBuilding objects from the file
            try
            {
                FileStream inFile = new FileStream(@"Files\ResourceBuilding.txt", FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                input = reader.ReadLine();
                while (input != null)
                {
                    x = int.Parse(input);
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    faction = reader.ReadLine();
                    symbol = reader.ReadLine();
                    resourceType = reader.ReadLine();
                    resourcesPerGameTick = int.Parse(reader.ReadLine());
                    resourcesRemaining = int.Parse(reader.ReadLine());

                    ResourceBuilding rB = new ResourceBuilding(x, y, health, faction, symbol, resourceType, resourcesPerGameTick, resourcesRemaining);
                    buildingsOnMap.Add(rB);
                    grid[x, y] = rB.Symbol;

                    //update arraySize
                    numberOfBuildingsOnMap++;
                    input = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }
            catch (IOException fe)
            {
                success = false;
                Console.WriteLine(fe.Message);
            }

            // load ResourceBuilding objects from the file
            try
            {
                FileStream inFile = new FileStream(@"Files\FactoryBuilding.txt", FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                input = reader.ReadLine();
                while (input != null)
                {
                    x = int.Parse(input);
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    faction = reader.ReadLine();
                    symbol = reader.ReadLine();
                    unitsToProduce = int.Parse(reader.ReadLine());
                    gameTicksPerProduction = int.Parse(reader.ReadLine());
                    spawnPointX = int.Parse(reader.ReadLine());
                    spawnPointY = int.Parse(reader.ReadLine());

                    FactoryBuilding fB = new FactoryBuilding(x, y, health, faction, symbol, unitsToProduce, gameTicksPerProduction, spawnPointX, spawnPointY);
                    buildingsOnMap.Add(fB);
                    grid[x, y] = fB.Symbol;

                    //update arraySize
                    numberOfBuildingsOnMap++;
                    input = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }
            catch (IOException fe)
            {
                success = false;
                Console.WriteLine(fe.Message);
            }
            return success;
        }

    }
}