﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Assignment1_16093549
{
    class ResourceBuilding : Building 
    {
        private string resourceType;
        private int resourcesPerGameTick;
        private int resourcesRemaining;

        public string ResourceType
        {
            get { return resourceType; }
            set { resourceType = value; }
        }

        public int ResourcesPerGameTick
        {
            get { return resourcesPerGameTick; }
            set { resourcesPerGameTick = value; }
        }

        public int resourcesremaining
        {
            get { return resourcesRemaining; }
            set { resourcesRemaining = value; }
        }

        public ResourceBuilding(int x, int y, int health, string faction, string symbol, string resourceType, int resourcesPerGameTick, int resourcesRemaining)
            : base(x, y, health, faction, symbol)
        {
            this.resourceType = resourceType;
            this.resourcesPerGameTick = resourcesPerGameTick;
            this.resourcesRemaining = resourcesRemaining;

        }

        public void generateResources()
        {
            if (resourcesRemaining >= 0)
                resourcesRemaining -= resourcesPerGameTick;
        }



        public override bool isAlive()
        {
            if (health > 0)
                return true;
            else
                return false;
        }

        public override string toString()
        {
            string output = base.toString()
                + "resourceType " + resourceType + Environment.NewLine
                + "resourcesPerGameTick" + resourcesPerGameTick + Environment.NewLine
                + "resourcesRemaining" + resourcesRemaining + Environment.NewLine;
                
            return output;
        }

        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {

                outFile = new FileStream(@"Files\ResourceBuilding.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);
                writer.WriteLine(x);
                writer.WriteLine(y);
                writer.WriteLine(health);
                writer.WriteLine(faction);
                writer.WriteLine(symbol);
                writer.WriteLine(resourceType);
                writer.WriteLine(resourcesPerGameTick);
                writer.WriteLine(resourcesRemaining);
                writer.Close();
                outFile.Close();
            }
            catch (IOException fe)
            {
                Console.WriteLine("IOExeption: " + fe.Message);
            }
            finally
            {
                if (outFile != null)
                    outFile.Close();
                if (writer != null)
                    writer.Close();
            }

        }
    }
}
