﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;



namespace Assignment1_16093549
{
    class RegenBuilding : FactoryBuilding
    {


        // constructor 
        public RegenBuilding(int x, int y, int health, string faction, string symbol, int unitsToProduce, int gameTicksPerProduction, int spawnPointX, int spawnPointY)
            : base(x, y, health, faction, symbol, unitsToProduce, gameTicksPerProduction, spawnPointX, spawnPointY)
        {

        }

        public override bool isAlive()
        {
            if (health > 0)
                return true;
            else
                return false;
        }

        public override string toString()
        {
            string output = base.toString()

                + "unitsToProduce " + unitsToProduce + Environment.NewLine
                + "gameTicksPerProduction" + gameTicksPerProduction + Environment.NewLine
                + "spawnPointX" + spawnPointX + Environment.NewLine
                + "spawnPointY" + spawnPointY + Environment.NewLine;

            return output;
        }


        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {

                outFile = new FileStream(@"Files\ResourceBuilding.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);
                writer.WriteLine(x);
                writer.WriteLine(y);
                writer.WriteLine(health);
                writer.WriteLine(faction);
                writer.WriteLine(symbol);
                writer.WriteLine(unitsToProduce);
                writer.WriteLine(gameTicksPerProduction);
                writer.WriteLine(spawnPointX);
                writer.WriteLine(spawnPointY);
                writer.Close();
                outFile.Close();
            }
            catch (IOException fe)
            {
                Console.WriteLine("IOExeption: " + fe.Message);
            }
            finally
            {
                if (outFile != null)
                    outFile.Close();
                if (writer != null)
                    writer.Close();
            }

        }

        public Unit spawnNewUnit()
        {
            if (unitsToProduce > 0)
            {
                Random rnd = new Random();
                if (rnd.Next(0, 2) == 0)
                {

                    //MeleeUnit
                    MeleeUnit mU = new MeleeUnit(spawnPointX, spawnPointY, 100, -1, true, 1, this.Faction, "M", "Club");
                    unitsToProduce--;
                    return mU;
                }
                else
                {

                    //RangedUnit
                    RangedUnit rU = new RangedUnit(spawnPointX, spawnPointY, 100, -1, true, 5, this.Faction, "R", "Gun");
                    unitsToProduce--;
                    return rU;
                }
            }
            else
                return null;
        }


        public void regen(Unit u)
        {
            Unit closest = null;
            int attackRangeX, attackRangeY;
            int shortestRange = 1000;

            attackRangeX = Math.Abs(this.x - u.X);
            attackRangeY = Math.Abs(this.y - u.Y);

            if (attackRangeX < shortestRange)
            {
                shortestRange = attackRangeX;
                u.Health = 100;
            }
        }
    }

}
