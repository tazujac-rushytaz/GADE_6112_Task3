﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;


namespace Assignment1_16093549
{
    class Building
    {
        protected int x;
        protected int y;
        protected int health;
        protected string faction;
        protected string symbol;

        // constructor 
        public Building(int x, int y, int health, string faction, string symbol) 
        {
            this.x = x;
            this.y = y;
            this.health = health;
            this.Faction = faction;
            this.symbol = symbol;
        }

        // destructor
        ~Building()
        {
        }

        public int X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        public int Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }

        public int Health
        {
            get
            {
                return health;
            }
            set
            {
                health = value;
            }
        }
        public string Faction
        {
            get
            {
                return faction;
            }
            set
            {
                faction = value;
            }
        }

        public string Symbol
        {
            get
            {
                return symbol;
            }
            set
            {
                symbol = value;
            }
        }

        public virtual bool isAlive() { return true; }


        public virtual string toString()
        {
            string output = "x : " + X + Environment.NewLine
                            + "y : " + Y + Environment.NewLine
                            + "Health" + Health + Environment.NewLine
                            + "Faction : " + Faction + Environment.NewLine
                            + "Symbol : " + Symbol + Environment.NewLine;
            return output;
        }

        public virtual void save()
        {

        }


    }
}